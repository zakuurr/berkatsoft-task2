### Configuration

Panduan langkah-langkah berikut ini yang akan memberi tahu Anda cara menjalankan lingkungan pengembangan.

```
$ composer install
$ Atur nama database pada file .env
$ Jalankan command "php artisan key:generate"
$ Jalankan command "php artisan migrate:fresh --seed"
$ Jalankan "php artisan serve" pada folder utama dari projek dan kunjungi http://127.0.0.1:8000 (kondisi default)
```

### Doccumentation

`http://127.0.0.1:8000/login`
email : admin@gmail.com
password : reza123
