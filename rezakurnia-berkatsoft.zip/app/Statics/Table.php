<?php

namespace App\Statics;


class Table
{
    public const CUSTOMERS = "customers";
    public const PRODUCTS = "products";
    // public const USER = "users";
}
